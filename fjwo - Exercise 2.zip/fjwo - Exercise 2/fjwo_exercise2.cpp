//
// Code to calculate two matrices A and B and the product AB
// Each process calculates some amount of lines of A and the corresponding lines of AB
//

#include <iostream>
#include <mpi.h>
#include <math.h>
using namespace std;

int main(){
  int rank, size, ierr, rem, jp, ip;
  //Change the size of the Matrices and the number of processes here
  int N=7, nproc=4;
  int factor=((N - (N % nproc))/nproc);
  int B[N][N], A[N][N], D[N][N]={0};
  int E[(factor+1)*nproc][N], F[(factor+1)*nproc][N];
  int a[factor+1][N]={0};
  int c[factor+1][N]={0};

  MPI_Comm comm;

  comm  = MPI_COMM_WORLD;

  MPI_Init(NULL,NULL);
  MPI_Comm_rank(comm, &rank);
  MPI_Comm_size(comm, &size);


  //In the case that nproc > N, limits the number of processes
  if (rank < N) {

    //Ensures that the matrix c is 0
    for (int i=1; i<factor+2; i++) {
      for (int j=1; j<N+1; j++) {
        c[i-1][j-1] = 0;
      }
    }

    //Rank 0 calculates the value of B
    if (rank == 0) {
      for (int i=1; i<N+1; i++) {
        for (int j=1; j<N+1; j++) {
          B[i-1][j-1]=(j+i)*(N-j+1);
        }
      }
    }
    //Broadcasts B to the other processes
    MPI_Bcast(B, (N*N), MPI_INT, 0, comm);


    //Each process generates their lines of the Matrix A
    for (int i=1; i<N+1; i++) {
      a[0][i-1] = (N-i+rank+1+1)*(rank+1);
      if (nproc<N) {
        for (int j=1; j*nproc<N; j++) {
          if (rank+(j*nproc)<=N) {
            a[j][i-1] = (N-i+(rank+(j*nproc))+1+1)*((rank+(j*nproc))+1);
          }
        }
      }
    }


    //Each process calculates the values of AB for their lines of A
    for (int i=1; i<N+1; i++) {
      for (int j=1; j<N+1; j++) {
        c[0][i-1] = c[0][i-1] + a[0][j-1]*B[j-1][i-1];
        if (nproc<N) {
          for (int k=1; k*nproc<N; k++) {
            if (rank+(k*nproc)<N) {
              c[k][i-1] = c[k][i-1] + a[k][j-1]*B[j-1][i-1];
            }
          }
        }
      }
    }

    //In the case that no process has to deal with more than one line of A
    if (nproc>=N) {

      //Rank 0 collects all the lines for the matrix D
      MPI_Gather(c, N, MPI_INT, D, N, MPI_INT, 0, comm);

      //Outputs the matrix D
      cout<<"AB = "<<endl;
      for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
          cout << D[i][j]<<" ";
        }
        cout<<endl;
      }
    }

    //In the case that some processes must deal with more than one line of A
    if (nproc<N) {

      //If some processes deal with different number of lines of A
      if (N%nproc != 0) {
        MPI_Gather(c, (factor+1)*N, MPI_INT, E, (factor+1)*N, MPI_INT, 0, comm);
      //If the processes all have the same amount
      } else {
        MPI_Gather(c, (factor)*N, MPI_INT, E, factor*N, MPI_INT, 0, comm);
      }
      if (rank==0) {
        //Organises the lines of D into the appropriate order
        cout<<"AB = "<<endl;
        for (int i=0; i<(N % nproc); i++) {
          for (int j=i*(factor+1); j<(i*(factor+1))+factor+1; j++) {
            rank = (j-(j%(factor+1)))/(factor+1);
            jp = rank+(nproc)*(j%(factor+1));
            for (int k=0; k<N; k++) {
              F[jp][k] = E[j][k];
            }
          }
        }
          for (int j=(N%nproc)*(factor+1); j<(factor+1)*nproc; j++) {
            if (j%(factor+1) != factor) {
              rank = (j - (j%(factor+1)))/(factor+1);
              jp = rank + (nproc)*(j%(factor+1));
              for (int k=0; k<N; k++) {
                F[jp][k] = E[j][k];
              }
            }
          }

        if (N%nproc==0) {
          for (int i=0; i<(nproc*factor); i++) {
            ip = (i-(i%(factor)))/(factor) + (i%(factor))*nproc;
            for (int j=0; j<N; j++) {
              F[ip][j] = E[i][j];
            }
          }
        }

        //Removes the unnecessary lines at the end of D
        for (int i=0; i<N; i++) {
          for (int j=0; j<N; j++) {
            D[i][j] = F[i][j];
          }
        }

        //Outputs the matrix D
        for (int i=0; i<N; i++) {
          for (int j=0; j<N; j++) {
            cout<<D[i][j]<<" ";
          }
        cout<<endl;
        }
      }
    }

    MPI_Finalize();
  }
}
