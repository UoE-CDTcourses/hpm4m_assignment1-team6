
#include<iostream>
#include<mpi.h>
using namespace std;

int main(){
  int rank, N=17, nproc, nrows, offset, extra_rows;
  int matrix_size;
  MPI_Comm comm;
  comm  = MPI_COMM_WORLD;

  MPI_Init(NULL,NULL);
  MPI_Comm_rank(comm, &rank);
  MPI_Comm_size(comm, &nproc);

  nrows = N/nproc;
  while(nproc*nrows<N){
    nrows++;
  }

  matrix_size = nrows*nproc;
  int B[matrix_size][N], D[matrix_size][N];
  int A[nrows][N], C[nrows][N];

  if(rank==0){
    // Initialise matrix B
    for(int i = 1; i <= N; i++){
      for(int j = 1; j <= N; j++){
        B[i-1][j-1] = (j + i)*(N - j + 1);
      }
    }
    // Print matrix B
    cout << "B built correctly on rank 0?" << endl; // Yes
    for(int i = 0; i < N; i++){
      for(int j = 0; j < N; j++){
        cout << B[i][j] <<" " ;
      }
      cout << endl;
    }
    cout << endl;
  }
  // Broadcast to other processes from 0
  MPI_Barrier(comm);
  MPI_Bcast(&B, matrix_size*N, MPI_INT, 0, comm);

  // Build submatrix of A on every rank
  for(int i=0; i<nrows; i++){
    for(int j=0; j<N; j++){
      offset = rank*nrows;
      A[i][j] = (N - (j+1) + (offset+i+1) + 1)*(offset+i+1);
    }
  }

  cout << "A built on rank as"<<rank << endl;
  for(int i = 0; i < nrows; i++){
    for(int j = 0; j < N; j++){
      cout << A[i][j] <<" " ;
    }
    cout << endl;
  }
  cout << endl;
  //  Submatrix multiplication on every rank
  for(int i = 0; i < nrows; i++){
    for(int j = 0; j < N; j++){
      C[i][j] = 0;
      for(int k = 0; k < N; k++){
        C[i][j] +=  A[i][k]*B[k][j];
      }
    }
  }

  // Print product
  cout << "C product on rank "<<rank << endl;
  for(int i = 0; i < nrows; i++){
    for(int j = 0; j < N; j++){
      cout << C[i][j] <<" " ;
    }
    cout << endl;
  }
  cout << endl;

  // Gather all the rows from separate processes
  MPI_Gather(&C[0][0], N*nrows, MPI_INT, D, N*nrows, MPI_INT, 0, comm);
  MPI_Barrier(comm);
  // Check if D has been gathered
  if(rank==0){
  cout << "D gathered correctly on rank "<<rank << endl;
  for(int i = 0; i < N; i++){
    for(int j = 0; j < N; j++){
      cout << D[i][j] <<" " ;
    }
    cout << endl;
  }
  cout << endl;
  }

  MPI_Finalize();
  return 0;
}
